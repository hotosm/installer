These files are for testing various rendering parts of mapnik, they have been created by hand.
The raw files are in the raw/ folder (they were created with inkscape to assist!)
Run the regenerate.sh script to regenerate the shape files from the gml files, this requires ogr2ogr to run.
