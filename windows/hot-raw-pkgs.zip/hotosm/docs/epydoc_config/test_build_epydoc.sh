rm -rf test_api
epydoc --no-private --no-frames --no-sourcecode --name mapnik --url http://mapnik.org --css mapnik_epydoc.css mapnik -o test_api
